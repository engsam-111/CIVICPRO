# CIVICPRO Authentication and Authorization

**Status:** Documentation of the uploaded repository snapshot  
**Reviewed:** 2026-11-10  
**Scope:** React frontend, Clerk identity provider, FastAPI API, MongoDB workspace membership

## 1. Architecture at a glance

CIVICPRO delegates identity and credential lifecycle to **Clerk**. The React application uses Clerk's React SDK for sign-up, sign-in, email verification/MFA, browser session state and sign-out. API calls obtain a Clerk session JWT and send it to the FastAPI backend as a Bearer token. FastAPI verifies the JWT against Clerk's JSON Web Key Set (JWKS), then loads CIVICPRO-specific membership and role data from MongoDB.

```text
Browser / React
  AuthForms.jsx + ClerkAuthProvider.jsx
       | Clerk sign-up/sign-in and session
       v
  Clerk session JWT -- Authorization: Bearer <JWT>
       |
       v
FastAPI /api/*
  require_user() -> verify_session_token() -> Clerk JWKS
       |
       v
  _identity() -> MongoDB users collection
       |
       v
  current_member() -> active membership required
       |
       +--> require_manager() -> manager-only operations
```

Clerk authenticates a person. CIVICPRO authorizes that authenticated person to use the workspace and determines their role. These are separate responsibilities.

## 2. Frontend components and responsibilities

| File | Responsibility |
|---|---|
| `frontend/src/components/auth/AuthForms.jsx` | Sign-up, password sign-in, email-code verification and sign-in MFA UI. Uses Clerk's sign-up/sign-in APIs. |
| `frontend/src/components/auth/ClerkAuthProvider.jsx` | Loads Clerk configuration and mounts the Clerk provider. |
| `frontend/src/lib/api.js` | `useApi()` obtains the current Clerk token and attaches `Authorization: Bearer ...` to Axios requests. `useResource()` loads API resources. `MeProvider` exposes the CIVICPRO member profile. |
| `frontend/src/App.js` | `AuthGate` protects application routes; signed-out users are redirected to `/sign-in`. |
| `frontend/src/components/civic/Shell.jsx` | Loads the current member, gates inactive accounts, shows role-aware navigation and Clerk's `UserButton` for account/logout actions. |

The frontend does not submit or store a locally managed password database. Clerk owns password validation, email verification and session management.

## 3. Backend authentication and authorization components

| File / function | Responsibility |
|---|---|
| `backend/clerk_auth.py::require_user` | Reads a Bearer token; falls back to the `__session` cookie if no Bearer token is present. Returns the verified Clerk subject and session ID. |
| `backend/clerk_auth.py::verify_session_token` | Obtains a signing key from Clerk JWKS and validates the JWT signature using RS256, required claims (`exp`, `iat`, `sub`, `iss`) and five seconds of clock-skew allowance. Validates the issuer against the configured Clerk domain, with an additional production proxy-issuer fallback described in the security plan. |
| `backend/server.py::_identity` | Finds or provisions the CIVICPRO MongoDB user record. Retrieves profile information from Clerk when needed. |
| `backend/server.py::current_member` | Requires the CIVICPRO membership status to be `active`. Pending and rejected accounts receive HTTP 403. |
| `backend/server.py::require_manager` | Requires `role == "manager"`; used for team administration. |
| `backend/server.py::rate_limit` | Applies per-process, per-user in-memory request limits to selected endpoints. |

### Authorization chain

1. `require_user()` proves possession of a valid Clerk session JWT.
2. `_identity()` maps the Clerk `sub` to the CIVICPRO `users.user_id` record and synchronizes basic profile information when necessary.
3. `current_member()` blocks pending and rejected users from normal workspace endpoints.
4. `require_manager()` applies manager-only permissions to sensitive administration endpoints.

`GET /api/me` intentionally uses `_identity()` rather than `current_member()` so a newly registered user can see their pending/rejected state and the UI can explain what action is required.

## 4. Sign-up request flow

1. The user opens `/sign-up` and submits email/password through `AuthForms.jsx`.
2. The frontend calls Clerk `signUp.password(...)`.
3. The frontend requests an email verification code with `signUp.verifications.sendEmailCode()`.
4. The user enters the code; the frontend calls `verifyEmailCode()`.
5. The frontend finalizes the Clerk sign-up with `signUp.finalize()`.
6. The signed-in app loads `/api/me`. Backend `_identity()` retrieves the verified Clerk profile and creates the CIVICPRO membership record if one does not exist.
7. New users default to the configured default role (currently `engineer`) and `pending` status. An email matching a verified address in `ADMIN_EMAIL` is provisioned as an active manager/owner.
8. `Shell.jsx` displays the waiting-for-approval screen until a manager approves the member.

## 5. Sign-in request flow

1. The user submits email/password through `AuthForms.jsx` and Clerk `signIn.password(...)`.
2. If Clerk requires an email code/MFA step, the frontend sends and verifies the code using Clerk's sign-in verification APIs.
3. The frontend calls `signIn.finalize()` and Clerk establishes the browser session.
4. `useApi()` calls Clerk `getToken()` for API requests and attaches the JWT as a Bearer token.
5. FastAPI verifies the token and applies CIVICPRO membership checks.
6. A user whose Clerk password is in a reset-required state is shown the app's contact-manager flow; the app does not implement a public self-service forgotten-password route in this snapshot.

## 6. API request and token validation

For normal API calls, the browser sends:

```http
GET /api/projects HTTP/1.1
Authorization: Bearer <Clerk-session-JWT>
```

The backend:

- Requires `CLERK_SECRET_KEY` to be configured.
- Extracts the Bearer token (or the `__session` cookie fallback).
- Uses Clerk's JWKS endpoint and PyJWT to select the signing key and verify the RS256 signature.
- Requires `exp`, `iat`, `sub` and `iss` claims and allows five seconds of clock skew.
- Checks the issuer against the expected Clerk issuer; see P1 security issue in `SECURITY_AND_FEATURES_IMPLEMENTATION_PLAN.md`.
- Returns HTTP 401 for missing, expired, invalid-signature or invalid-issuer tokens.
- Uses `sub` as the Clerk user ID and `sid` as the session ID.

The frontend SDK manages the browser session and obtains session tokens as needed. This repository does not implement its own refresh-token database or token-rotation service.

## 7. Credentials, secrets and stored identity data

| Item | Where it is handled | Expected handling |
|---|---|---|
| User password | Clerk | Never store or log it in CIVICPRO MongoDB. |
| Email verification / MFA codes | Clerk | Managed by Clerk; never persist verification codes in app collections. |
| Browser session | Clerk SDK/browser | Frontend obtains a session JWT with `getToken()`; app API calls use Bearer authorization. |
| JWT signing keys | Clerk JWKS | Backend verifies signatures using Clerk's published JWKS. |
| `CLERK_PUBLISHABLE_KEY` | Frontend/provider configuration | Public identifier; not a password or secret. |
| `CLERK_SECRET_KEY` | Backend environment | Server-only secret used for Clerk backend API/JWKS access. Never expose in React build variables or API responses. |
| CIVICPRO member profile | MongoDB `users` | Stores Clerk `user_id`, email, name, role, status and audit-related metadata; not the user's password. |
| `ADMIN_EMAIL` | Backend environment | Comma-separated owner/admin email allowlist; protect environment access and keep values current. |

`GET /api/clerk/config` returns the publishable key and proxy URL, not the Clerk secret key. The production Clerk proxy forwards requests through `/api/__clerk` and adds the secret key server-side.

## 8. Roles and membership states

- **manager:** workspace/team administration and manager-only endpoints.
- **supervisor:** operational workspace access, subject to endpoint-specific permissions.
- **engineer:** standard operational workspace access.
- **pending:** authenticated, but not yet approved for the workspace.
- **active:** may use protected workspace endpoints subject to role permissions.
- **rejected:** authenticated, but denied workspace access.

The configured owner email(s) are protected from certain manager actions. Manager password reset is implemented through Clerk's backend API and requests sign-out of the target user's other sessions; the operation is audited. The reset endpoint enforces manager authorization and owner protections.

## 9. Existing email capability

`backend/mailer.py` sends email through the configured managed email integration using `EMERGENT_EMAIL_KEY` and `EMAIL_FROM_NAME`, with optional `EMAIL_REPLY_TO`. The existing overdue-issue reminder workflow in `backend/server.py` emails the assigned owner and copies active managers. This is a reusable foundation for the planned manager notification events, but it is not yet a general notification center or a complete event-notification framework.

## 10. Current limitations and review notes

- Production issuer validation accepts an additional HTTPS issuer ending in `/api/__clerk`; narrow this to a configured exact proxy origin.
- The current rate limiter is in-memory and per process; use a shared store such as Redis for multi-worker/multi-instance deployments.
- The backend accepts a session cookie as a fallback; explicitly document and enforce CSRF/origin protections if cookie-authenticated state-changing requests are supported.
- No general `notifications` collection/API or notification inbox UI was found in this snapshot.
- Project listing is currently a simple list; no archive state, archive/restore endpoint or dedicated archived-project view was found. The current project DELETE endpoint permanently deletes the project and related activity/report/issue records, so archive must be implemented as a separate reversible operation.
- The root `README.md` is currently a placeholder; this document is the first detailed authentication reference.

## 11. Related files and tests

- `backend/tests/test_iteration7_security.py`
- `backend/tests/test_iteration9_password_reset.py`
- `backend/server.py`
- `backend/clerk_auth.py`
- `backend/mailer.py`
- `frontend/src/components/auth/AuthForms.jsx`
- `frontend/src/components/auth/ClerkAuthProvider.jsx`
- `frontend/src/lib/api.js`
- `frontend/src/components/civic/Shell.jsx`
