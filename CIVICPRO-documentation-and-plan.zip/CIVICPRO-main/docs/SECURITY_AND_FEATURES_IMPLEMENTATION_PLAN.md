# CIVICPRO Security and Product Features — Prioritized Implementation Plan

**Prepared:** 2026-11-10  
**Baseline:** Uploaded `CIVICPRO-main.zip` repository snapshot  
**Purpose:** Implementation-ready plan. This document does not claim the fixes or product features below have already been coded or deployed.

## Executive summary

Keep Clerk as the identity provider and retain the current React → Clerk session JWT → FastAPI → MongoDB membership architecture. Do not introduce a second password store or custom JWT issuer. First tighten token issuer validation and production request controls. Then add a reversible project archive lifecycle, portfolio search/filtering, and a notification center with manager email delivery.

## Priority definitions

- **P0 — release blocker:** exploitable or high-impact security issue; fix before a production release if confirmed in the target deployment.
- **P1 — high:** security hardening or core requested functionality; schedule immediately after P0.
- **P2 — medium:** reliability, usability, operational visibility.
- **P3 — low:** optional refinements.

## A. Prioritized security fixes

| Priority | Finding / risk | Recommended change | Acceptance evidence |
|---|---|---|---|
| P1 | `backend/clerk_auth.py::verify_session_token` accepts a broad production issuer fallback: any HTTPS `iss` ending in `/api/__clerk`. Signature validation remains active, but issuer acceptance is broader than necessary. | Add a required `CLERK_PROXY_ISSUER` (exact expected issuer) or derive it from a trusted configured canonical application origin. Accept only the exact Clerk issuer or exact configured proxy issuer. Reject missing/malformed configuration in production; do not derive trust from request `Host`/`X-Forwarded-Host`. | Unit tests for exact valid issuer, unexpected HTTPS issuer, suffix lookalike, HTTP issuer, empty issuer and production misconfiguration. Existing valid production proxy session continues to work. |
| P1 | `rate_limit()` uses Python process memory (`_hits` / `defaultdict(deque)`). Limits reset on restart and are not shared across workers/instances. | Move counters to Redis or another shared atomic TTL store. Use atomic increment + expiry (Lua or equivalent), key by authenticated user and bucket, and add a safe failure policy for store outages. Keep stricter limits for password reset, uploads, exports and AI. | Integration tests with two app workers sharing one limiter; boundary, expiry, concurrency and outage tests. |
| P1 | `require_user()` accepts `__session` cookie fallback. Cookie-authenticated unsafe requests require explicit CSRF/origin strategy. | Prefer Bearer-only API authentication if cookie fallback is unnecessary. If cookie auth is retained, enforce CSRF tokens and strict Origin/Referer checks for POST/PATCH/PUT/DELETE, plus `SameSite`, `Secure` and `HttpOnly` cookie policy at the trusted edge. Never assume CORS alone is CSRF protection. | Tests proving cross-origin unsafe requests are rejected and legitimate app requests continue to work. |
| P1 | Manager email notifications will contain operational project information. | Use a notification service that obtains recipients only from active manager records, validates addresses, escapes all dynamic HTML, avoids secrets/private tokens in email, and logs delivery outcome without logging message contents or credentials. | Tests for manager-only recipient selection, HTML escaping, no email to pending/rejected users, idempotency and provider failure. |
| P2 | Current issuer/JWKS failure diagnostics are generic and auth provider startup retries may delay feedback. | Add structured, secret-safe auth configuration diagnostics and a readiness check. Never log JWTs, authorization headers, Clerk secret key or password-reset payloads. | Startup/configuration tests and log-redaction checks. |
| P2 | Project DELETE permanently removes linked activity/report/issue records and marks files deleted. | Add archive/restore and make permanent deletion a separate, manager-only, explicit confirmation workflow. Do not repurpose DELETE to mean archive without a migration and API compatibility review. | Regression tests proving archive preserves child records/files and restore reactivates the same project. |
| P2 | Security controls and test coverage need repeatable CI execution. | Run the existing security/password-reset suites on every PR; add the cases above and dependency scanning/secret scanning in CI. | CI required checks pass; no secrets committed. |
| P3 | `scripts/clerk_test_token.py` can mint real Clerk sessions using a secret. | Keep it out of production images and deployed runtime; restrict to local/test environments and document its use. | Production build excludes script or runtime guard blocks use in production. |

### Security implementation order

1. **Issuer pinning:** add exact configuration, fail closed in production, test all issuer edge cases.
2. **Shared rate limiting:** add Redis configuration, namespaced keys, TTL and safe failure behavior.
3. **CSRF decision:** confirm whether cookie fallback is required. Remove it if not; otherwise implement CSRF and origin enforcement.
4. **Email safety controls:** implement recipient resolver, HTML escaping, idempotency and audit metadata as part of notifications.
5. **CI and operational checks:** automate regression, dependency/secret scans and readiness diagnostics.

### Suggested configuration additions

```dotenv
# Exact proxy issuer if production Clerk proxy tokens use a proxy issuer.
# Do not set this to a wildcard, suffix or value taken from an incoming request.
CLERK_PROXY_ISSUER=https://<canonical-app-origin>/api/__clerk

# Shared rate-limit store (secret URL; server-side only).
REDIS_URL=redis://<private-host>:6379/0

# Manager notification controls.
MANAGER_NOTIFICATIONS_ENABLED=true
APP_BASE_URL=https://<canonical-civicpro-origin>
```

Use the deployment platform's secret manager for all credentials. The values above are examples/placeholders, not live credentials.

## B. Project archive, search and filters

### Product behavior

Add an **Archived** view/tab under Projects. Project lifecycle states should be explicit:

- `active` (default): visible in the standard Projects view and available for normal work.
- `archived`: hidden from the default active list, visible in the Archived view, read-only by default, and restorable by authorized users.

Archiving is not deletion. It must preserve the project record, activities, reports, issues, files, progress snapshots, exports and audit history. Restore returns the project to the active portfolio. Permanent deletion remains a distinct manager-only action with a clear irreversible warning and retention policy.

### Frontend behavior

- Projects page: segmented views **Active / Archived / All** (or Active and Archived tabs with counts).
- Search box: search project name, project code, location and client; case-insensitive, trimmed, debounced for server-side search if portfolio size grows. For a small portfolio, client-side filtering is acceptable initially, but server-side filtering is preferred for consistency and pagination.
- Filters: status (Active / At risk / Completed, plus any supported statuses), client, location, date range and progress range where fields exist.
- Sorting: newest, name, start date, finish date, progress; default newest first.
- Clear-filters action and a useful empty state distinguishing “no projects exist” from “no projects match these filters”.
- Project rows show archived status and archive date where appropriate.
- Project detail in archived state displays a clear archived banner and disables create/edit operations unless the user restores the project first.
- Mobile layout: search and filter controls must fit the current mobile navigation/responsive patterns; filters can open in a drawer/sheet.

### Backend/API design

Suggested additions (final route names can follow existing API conventions):

| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/api/projects?archive_state=active&q=&status=&client=&location=&start_from=&start_to=&sort=&page=&page_size=` | List and filter projects; default `archive_state=active`. |
| POST | `/api/projects/{pid}/archive` | Archive a project; require active member and preferably manager or explicitly authorized project role. |
| POST | `/api/projects/{pid}/restore` | Restore archived project; require manager or explicitly authorized project role. |
| DELETE | `/api/projects/{pid}` | Keep as permanent deletion only after adding manager authorization, explicit confirmation semantics and audit logging. |

Use a consistent document shape:

```json
{
  "archived": true,
  "archived_at": "2026-11-10T12:00:00Z",
  "archived_by": "<clerk-user-id>",
  "archived_by_name": "<display-name>"
}
```

For active projects, `archived` is false or absent; `archived_at` and `archived_by` are unset. Add indexes to support archive-state + created date, and search fields as appropriate. If using MongoDB text search, verify stemming/diacritics and ranking behavior; otherwise use normalized indexed fields or Atlas Search if available. Avoid unbounded regex scans on large collections.

### Authorization and data integrity

- Do not allow an engineer/supervisor to permanently delete projects by default.
- Decide whether archive/restore is manager-only or allowed to project owners; document and test the policy. Recommended initial policy: manager-only until project-level membership is implemented.
- Prevent normal edits, new activities, reports, issues and file uploads against archived projects unless a manager explicitly restores the project.
- Ensure dashboard KPIs, reports and exports clearly define whether archived projects are excluded (recommended: exclude by default; provide an explicit include-archived option).
- Add an audit event for archive and restore.
- Never cascade-delete children during archive.

### Acceptance tests

1. Newly created project appears in Active by default.
2. Archive removes it from Active and makes it visible in Archived.
3. Search works across name/code/location/client and is case-insensitive.
4. Status/client/location/date/progress filters combine correctly.
5. Clear filters restores the full view.
6. Restore returns project to Active with all original child records and attachments intact.
7. Archived project cannot receive normal edits, new reports, activities, issues or files.
8. Unauthorized role receives 403 for archive/restore/delete according to policy.
9. Dashboard and exports exclude archived projects by default and include them only when explicitly requested.
10. Test mobile breakpoints and empty/no-match states.

## C. In-app alerts and manager email notifications

### Recommended event types

Start with events that require management awareness:

- New user sign-up awaiting approval.
- User approved or rejected (optional notification to the affected user in a later iteration).
- New project created.
- Project archived or restored.
- New high-severity issue/risk created.
- Issue assigned/reassigned to a team member.
- Issue overdue reminder (existing daily reminder workflow already emails the assignee and active managers).
- Optional later: new daily/weekly site report submitted; project status changes to At risk.

### In-app notification center

Add a bell icon in the top bar with an unread-count badge and a Notifications panel/page.

Recommended MongoDB `notifications` document:

```json
{
  "id": "<uuid>",
  "recipient_user_id": "<clerk-user-id>",
  "event_type": "project.created",
  "title": "New project created",
  "message": "Project <project-name> was created by <actor-name>.",
  "entity_type": "project",
  "entity_id": "<project-id>",
  "project_id": "<project-id>",
  "created_at": "<UTC-ISO-8601>",
  "read_at": null,
  "email_status": "pending"
}
```

Do not store access tokens, passwords, verification codes or sensitive form payloads in notification documents. Keep message content concise and link to an authorized in-app record. API reads must always be scoped to the authenticated recipient.

Suggested API:

| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/api/notifications?unread_only=false&page=&page_size=` | Return only notifications for the current user. |
| GET | `/api/notifications/unread-count` | Return unread count for the current user. |
| PATCH | `/api/notifications/{notification_id}/read` | Mark one owned notification as read. |
| POST | `/api/notifications/read-all` | Mark all notifications belonging to the current user as read. |

Add a compound index on `(recipient_user_id, created_at)` and a supporting unread index if required. Enforce ownership in every read/update query; never trust a recipient ID supplied by the browser.

### Manager recipient resolution

Resolve managers from MongoDB, not from a hard-coded email list:

- `role` is `manager` (legacy `admin` may be included only while the migration remains supported).
- `status` is active (reuse the existing `ACTIVE` semantics carefully; for email recipients, require explicitly active rather than accidentally including records with missing status unless the migration policy says otherwise).
- email is present and passes basic validation.
- de-duplicate addresses case-insensitively.

Use `ADMIN_EMAIL` only for the protected owner identity/bootstrap policy, not as the general manager recipient list. Pending/rejected accounts must not receive manager operational alerts.

### Email delivery

Reuse `backend/mailer.py::send_email()` and the current managed email integration. Add event-specific templates with escaped dynamic content and links built only from the configured `APP_BASE_URL` (never an incoming Host header). Keep `EMAIL_FROM_NAME`, `EMAIL_REPLY_TO` and `EMERGENT_EMAIL_KEY` server-side.

Suggested email behavior:

- Send one manager notification email per event, with all active managers in the `to` list or use BCC if recipient privacy is required by the provider contract.
- Do not send duplicate email when an event handler retries. Add a stable `event_id` and an `email_delivery`/outbox record with a unique index on `(event_id, recipient_group)`.
- Record provider message ID, attempted/sent/failed status, attempt count and timestamps. Do not mark email sent until provider success is confirmed.
- In-app notification creation should succeed even if email delivery fails; email retries must not block the user action.
- Use a background task/worker or durable outbox for retries. Avoid fire-and-forget tasks that can disappear on process restart.
- Add configurable notification preferences later; initial release can enable critical manager alerts by default.

### Event-to-recipient matrix (initial recommendation)

| Event | In-app recipients | Email recipients |
|---|---|---|
| New user awaiting approval | All active managers | All active managers |
| New project created | All active managers | All active managers |
| Project archived/restored | All active managers | All active managers |
| High-severity issue created | All active managers + assigned owner if any | All active managers |
| Issue assigned/reassigned | Assigned active user + managers | Assigned user; managers optionally copied |
| Existing overdue reminder | Assignee + managers | Keep current behavior; add idempotent delivery tracking |

### Acceptance tests

1. New notification is visible to its intended recipient and unread count increments.
2. A user cannot list, read or mark another user's notification as read (404/403 consistently).
3. Mark-read and read-all update unread count correctly.
4. Only active managers receive manager events; pending/rejected users are excluded.
5. Dynamic HTML is escaped and email links use configured HTTPS app origin.
6. Email provider failure does not roll back the underlying project/issue/user action or the in-app alert.
7. Retry does not send duplicate email for the same event/recipient group.
8. No token, password, verification code or secret appears in logs, email or notification payloads.
9. Manager alert email is delivered in a staging test inbox; production delivery and cron operation are verified separately.

## D. Suggested delivery sequence

| Sprint / phase | Deliverables | Dependencies |
|---|---|---|
| Phase 0 — security baseline | Pin issuer; decide cookie/CSRF policy; shared rate limiter; security regression tests. | Deployment configuration and Redis availability. |
| Phase 1 — project lifecycle | Archive/restore API, audit events, manager policy, Active/Archived UI and safeguards against editing archived projects. | Phase 0 authorization hardening recommended. |
| Phase 2 — portfolio discovery | Search, filters, sorting, pagination, archive-aware dashboard/export semantics. | Phase 1 data contract. |
| Phase 3 — notification foundation | Notification collection, indexes, recipient resolver, scoped APIs, notification bell/inbox and read states. | Authenticated user IDs and event definitions. |
| Phase 4 — manager email | Durable outbox, templates, idempotency, retries, provider monitoring, event subscriptions. | Phase 3 event model and existing mailer integration. |
| Phase 5 — production verification | Regression suite, staging inbox delivery, role matrix, mobile UX, migration/rollback and operational runbook. | All prior phases. |

## E. Release checklist

- [ ] Back up MongoDB before schema/index changes.
- [ ] Add migration-safe defaults for existing projects (`archived` absent means active).
- [ ] Pin production issuer and test real Clerk sign-in through the configured proxy.
- [ ] Configure shared rate-limit store and verify multi-instance behavior.
- [ ] Confirm cookie fallback/CSRF decision and test unsafe cross-origin requests.
- [ ] Confirm manager notification recipient rules and active status semantics.
- [ ] Configure email integration secrets and canonical HTTPS `APP_BASE_URL`.
- [ ] Test provider failure, retries and duplicate suppression.
- [ ] Verify archived projects are excluded from default KPIs/exports and can be restored without data loss.
- [ ] Verify mobile and desktop layouts.
- [ ] Run backend security, password reset, project CRUD, reports/issues, file, export and frontend build tests.
- [ ] Deploy to staging first; verify real email delivery and Clerk proxy issuer; then promote to production.

## F. Out of scope for this plan

- Replacing Clerk with custom password storage or custom token issuance.
- Permanent deletion/retention policy automation beyond a separately approved manager-only delete workflow.
- Real-time WebSocket/push notifications; initial inbox can poll on focus/interval and refresh after user actions. Push can be a later phase.
- Per-user notification preference center; initial manager-critical notifications are enabled by policy.
