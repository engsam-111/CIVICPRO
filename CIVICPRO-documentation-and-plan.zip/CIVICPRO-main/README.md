# CIVICPRO

Construction project operations workspace.

## Technical documentation

- [Authentication and authorization](docs/AUTHENTICATION.md)
- [Prioritized security fixes and product implementation plan](docs/SECURITY_AND_FEATURES_IMPLEMENTATION_PLAN.md)

The documentation describes the uploaded source snapshot and separates existing behavior from planned work. The archive/search/filter and notification features in the implementation plan are specifications and are **not represented as implemented or deployed** by this documentation update.
